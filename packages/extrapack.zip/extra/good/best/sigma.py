#!/usr/bin/env python3

"""module: sigma"""

def funS():
    return "Sigma"

if __name__ == "__main__":
    print("I prefer to be a module.")